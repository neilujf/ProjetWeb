<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">


    <title>Esiee-Learning</title>

    <link href="./dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="./dist/js/bootstrap.min.css" rel="stylesheet">
	
	<script type="text/javascript" src="./dist/js/modal.js"></script>

  </head>

  <body>
  
<!-- DEBUT Nav bar  -->

<nav class="navbar navbar-inverse " role="navigation">
    <div class="container">
		
        <div id="navbar" class="navbar-form navbar-left">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">Esiee-Learning</a>
			</div>
				
			<ul class="nav navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="#">Truc 1</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Truc2</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">...</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="./formations.php">Formations</a>
				</li>
			</ul>		
		</div>

		<div id="navbar" class="navbar-form navbar-right">
			<ul class="nav navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="#">Se déconnecter</a>
				</li>
			</ul>	
		</div>
		    
    </div><!-- Container -->
</nav>

<!-- FIN Nav bar  -->

<?php
	include("./api/createReservation.php");
?>

<div class="container text-center">
  <hr>
  
  <footer>	
  <div class="container text-center"
	<p>&copy; Esiee-Learning - PROJET ESIEE 2017 - All Rights Reserved</p>
  </div>
  </footer>
  
</div> <!-- /container -->

<!-- ---------------------->

<!----     -->
  </body>
</html>
