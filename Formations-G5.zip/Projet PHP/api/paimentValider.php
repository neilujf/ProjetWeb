<?php
require 'db_config.php';

if (isset ($_POST['numero_carte']) AND isset ($_POST['date']) AND isset ($_POST['crypto']) AND $_POST['numero_carte']!= "" AND $_POST['date']!="" AND $_POST['crypto']!="")
{	
	$sql = "UPDATE reservation SET 	transaction_effectue=true, date_transaction=now() WHERE id=".$_POST['id_reservation'];
	if ($mysqli->query($sql))
	{
		//redirection vers page d'acceuil
		echo "Paiement accepté";
		?> <meta http-equiv="refresh" content="5;url=./../formations.php"/><?php
	}
	else
	{
		echo "Problème de paiement";
		?> <meta http-equiv="refresh" content="5;url=./../formations.php"/><?php
	}
}
else
	{
		echo "Vous n'avez pas renseigné tous les champs obligatoires, vous allez être redirigé !";
		?> <meta http-equiv="refresh" content="5;url=./../formations.php"/><?php
	}
	
?>
