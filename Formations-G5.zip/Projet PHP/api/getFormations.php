<?php
require 'db_config.php';


$sql = "SELECT * FROM formations";
$result_formation = $mysqli->query($sql);

while($row = $result_formation->fetch_assoc()){
	$id_formation = $row['id'];
	$nom = $row['nom'];
	$prix = $row['prix'];
	$professeur_id = $row['id_Professeurs'];
	$cours_id = $row['id_Cours'];
	
	// info professeur
	$result = $mysqli->query("SELECT * FROM professeurs WHERE id=".$professeur_id);
	$result_professeur = $result->fetch_assoc();
	$professeur_name = $result_professeur['nom'];
	
	// info cours
	$result = $mysqli->query("SELECT * FROM cours WHERE id=$cours_id");
	$result_cours = $result->fetch_assoc();
	$cours_date_debut = $result_cours['date_debut'];
	$cours_date_fin = $result_cours['date_fin'];
	$cours_lieu = $result_cours['lieu'];
	?>
	<div class="col-md-3">
		<form method="post" action="payement.php">
			<h2><?php echo $nom ?></h2>
			<h5>Lieu : <?php echo $cours_lieu ?></br>
			  Avec le professeur: <?php echo $professeur_name ?></h5>
			<h5>Du: <?php echo $cours_date_debut ?></br>
			  Au: <?php echo $cours_date_fin ?></h5>
			<h4>Prix : <?php echo $prix ?>€</h4>
			</br>
			<input type="hidden" name="id_formation" value="<?php echo $id_formation ?>"/>
			<input type="hidden" name="id_client" value="1"/> <!-- A METTRE ICI L'ID DE L'UTILISATEUR-->
			<input class="btn btn-success" type="submit" value="Commander &raquo"/>
		</form>
	</div>
	<?php
}
?>