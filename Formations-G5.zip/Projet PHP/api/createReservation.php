<?php
require 'db_config.php';

if (isset($_POST['id_formation']) AND isset($_POST['id_client']))
{
	$post = $_POST;

	$sql = "INSERT INTO reservation (transaction_effectue,id_Clients, id_Formations) 
	VALUES (
	  false,
	  ".$post['id_client'].",
	  ".$post['id_formation']."
	)";

    if($mysqli->query($sql))
	{
		$id_reservation = mysqli_insert_id($mysqli);

	?>
		<div class="container">
			</br>
			<h2>Payement  : REF<?php echo $id_reservation ?><h2>
			</br>
		</div>

		<div class="container text-center">		  
			<div class="col-md-4 col-md-offset-4">		
				<form class="form-horizontal" action="./api/paimentValider.php" method="post">
					<div class="form-group">
						<label class="control-label col-sm-2" for="numero_carte">Numéro de carte: </label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="numero_carte" placeholder="XXXX XXXX XXXX XXXX">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="date">Date d'éxpiration: </label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="date" placeholder="mm/yy">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-sm-2" for="cb">Cryptogramme Visuel: </label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="crypto" placeholder="XXX">
						</div>
					</div>
					<input type="hidden" name="id_reservation" value="<?php echo $id_reservation ?>"/>
					<a class="btn btn-warning" href="./formations.php" role="button">Retour</a>
					<input class="btn btn-success" type="submit" value="Valider &raquo"/>
				</form>
			</div>
	</div><!-- /container -->
	
	
<?php
	}
	else
	{
		?>
		<div class="container text-center">
			</br>
			<h2>ERREUR lors de l'insertion !<h2>
			</br>
		</div>
<?php
	}
}
else
{?>		
	<div class="container text-center">
		</br>
		<h2>ERREUR lors de la réservation !<h2>
		<h5>(Vérifiez que vous êtes bien connecté !)</h5>
		</br>
	</div>
<?php 
	}
?>